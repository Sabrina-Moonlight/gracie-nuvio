package com.nuvio.app.features.player

import com.nuvio.app.features.servers.ServerItemRef
import com.nuvio.app.features.servers.ServerStreams
import com.nuvio.app.features.tmdb.TmdbService
import com.nuvio.app.features.tracking.TrackingMediaReference
import com.nuvio.app.features.tracking.TrackingScrobbleAction
import com.nuvio.app.features.tracking.TrackingScrobbleCoordinator
import com.nuvio.app.features.tracking.TrackingScrobbleEvent
import com.nuvio.app.features.tracking.buildTrackingMediaReference
import com.nuvio.app.features.watchprogress.WatchProgressClock
import com.nuvio.app.features.watchprogress.WatchProgressPlaybackSession
import com.nuvio.app.features.watchprogress.WatchProgressRepository
import com.nuvio.app.features.watchprogress.buildPlaybackVideoId
import com.nuvio.app.features.watching.domain.isShortPlaceholderDuration
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import nuvio.composeapp.generated.resources.Res
import nuvio.composeapp.generated.resources.player_engine_switching_automatic_message
import nuvio.composeapp.generated.resources.player_engine_switching_manual_message
import kotlin.math.abs
import kotlin.time.TimeSource

internal fun PlayerScreenRuntime.finishTimelineScrub(positionMs: Long) {
    lastManualSkipSeekPositions = playbackSnapshot.positionMs to positionMs
    isScrubbingTimeline = false
    scrubbingPositionMs = positionMs.takeIf { playbackSnapshot.isLoading }
}

internal fun PlayerScreenRuntime.updatePlaybackSnapshot(
    snapshot: PlayerPlaybackSnapshot,
    playbackKey: PlaybackKey = activePlaybackKey,
): Boolean {
    if (playbackKey != activePlaybackKey) return false
    val reported = if (partyRateNudge != null) snapshot.copy(playbackSpeed = partyBaseRate()) else snapshot
    playbackSnapshot = if (reported.durationMs <= 0L && playbackSnapshotKey == playbackKey) {
        reported.copy(durationMs = playbackSnapshot.durationMs)
    } else {
        reported
    }
    playbackSnapshotKey = playbackKey
    playbackSnapshotMark = TimeSource.Monotonic.markNow()
    val targetPositionMs = scrubbingPositionMs ?: return true
    if (!isScrubbingTimeline && (
            !snapshot.isLoading || snapshot.isEnded ||
                abs(snapshot.positionMs - targetPositionMs) <= 1_000L
            )
    ) {
        scrubbingPositionMs = null
    }
    return true
}

internal val PlayerScreenRuntime.activePlaybackIdentity: String
    get() = activeTorrentInfoHash
        ?.let { hash -> "torrent:$hash:${activeTorrentFileIdx ?: -1}" }
        ?: activeSourceUrl

internal val PlayerScreenRuntime.activePlaybackKey: PlaybackKey
    get() = PlaybackKey(
        sourceIdentity = activePlaybackIdentity,
        videoId = activeVideoId,
        seasonNumber = activeSeasonNumber,
        episodeNumber = activeEpisodeNumber,
        playbackEngine = playbackEngineOverride,
    )

internal val PlayerScreenRuntime.sourcePlaybackKey: PlaybackKey
    get() = PlaybackKey(
        sourceIdentity = activePlaybackIdentity,
        videoId = activeVideoId,
        seasonNumber = activeSeasonNumber,
        episodeNumber = activeEpisodeNumber,
    )

internal val PlayerScreenRuntime.playbackSession: WatchProgressPlaybackSession
    get() = WatchProgressPlaybackSession(
        profileId = profileId,
        contentType = contentType ?: parentMetaType,
        parentMetaId = parentMetaId,
        parentMetaType = parentMetaType,
        videoId = activeVideoId?.takeIf { it.isNotBlank() } ?: buildPlaybackVideoId(
            parentMetaId = parentMetaId,
            seasonNumber = activeSeasonNumber,
            episodeNumber = activeEpisodeNumber,
            fallbackVideoId = activeVideoId,
        ),
        title = title,
        logo = logo,
        poster = poster,
        background = background,
        seasonNumber = activeSeasonNumber,
        episodeNumber = activeEpisodeNumber,
        episodeTitle = activeEpisodeTitle,
        episodeThumbnail = activeEpisodeThumbnail,
        providerName = activeProviderName,
        providerAddonId = activeProviderAddonId,
        lastStreamTitle = activeStreamTitle,
        lastStreamSubtitle = activeStreamSubtitle,
        pauseDescription = activePauseDescription,
        lastSourceUrl = activeSourceUrl.takeUnless { ServerStreams.isServerSourceId(activeProviderAddonId) },
    )

internal fun PlayerScreenRuntime.currentLaunch(launch: PlayerLaunch): PlayerLaunch {
    val positionMs = playbackSnapshot.positionMs.takeIf {
        it > 0L && initialSeekApplied && playbackSnapshotKey == activePlaybackKey
    }
    return launch.copy(
        sourceUrl = activeSourceUrl,
        sourceAudioUrl = activeSourceAudioUrl,
        sourceHeaders = activeSourceHeaders,
        sourceResponseHeaders = activeSourceResponseHeaders,
        externalSubtitles = externalSubtitles,
        streamType = activeStreamType,
        seasonNumber = activeSeasonNumber,
        episodeNumber = activeEpisodeNumber,
        episodeTitle = activeEpisodeTitle,
        episodeThumbnail = activeEpisodeThumbnail,
        streamTitle = activeStreamTitle,
        streamSubtitle = activeStreamSubtitle,
        bingeGroup = currentStreamBingeGroup,
        pauseDescription = activePauseDescription,
        providerName = activeProviderName,
        providerAddonId = activeProviderAddonId,
        videoId = activeVideoId,
        torrentInfoHash = activeTorrentInfoHash,
        torrentFileIdx = activeTorrentFileIdx,
        torrentFilename = activeTorrentFilename,
        torrentTrackers = activeTorrentTrackers,
        sourceFilename = activeSourceFilename,
        initialPositionMs = positionMs ?: activeInitialPositionMs,
        initialProgressFraction = activeInitialProgressFraction.takeIf { positionMs == null },
    )
}

internal fun PlayerScreenRuntime.resetIdentityStateIfNeeded() {
    val sourceIdentity = sourcePlaybackKey
    if (lastResetSourcePlaybackIdentity != sourceIdentity) {
        lastResetSourcePlaybackIdentity = sourceIdentity
        engineFailoverTriggered = false
        engineFailoverDisarmed = false
        engineFailoverSourceIdentity = null
        playbackEngineOverride = null
        autoFetchedAddonSubtitlesForKey = null
    }

    val identity = activePlaybackKey
    if (lastResetPlaybackIdentity != identity) {
        lastResetPlaybackIdentity = identity
        shouldPlay = true
        initialLoadCompleted = false
        speedBoostRestoreSpeed = null
        isHoldToSpeedGestureActive = false
        initialSeekApplied = activeInitialPositionMs <= 0L &&
            (activeInitialProgressFraction == null || activeInitialProgressFraction!! <= 0f)
        lastProgressPersistEpochMs = 0L
        previousIsPlaying = false
        pendingSeekScrobbleRestart = false
        trackPreferenceRestoreApplied = false
        preferredAudioSelectionApplied = false
        appliedAudioPreferences = null
        preferredSubtitleSelectionApplied = false
        isUserExplicitAudioSelection = false
        isUserExplicitSubtitleSelection = false
        hasScannedTextTracksOnce = false
    }

    val videoIdentity = "$identity:$activeVideoId:$activeSeasonNumber:$activeEpisodeNumber"
    if (lastResetVideoIdentity != videoIdentity) {
        lastResetVideoIdentity = videoIdentity
        hasRequestedScrobbleStartForCurrentItem = false
        scrobbleStartRequestGeneration = 0L
        pendingSeekScrobbleRestart = false
        hasSentCompletionScrobbleForCurrentItem = false
        currentTrackingMedia = null
    }
}

internal fun PlayerScreenRuntime.resetAddonSubtitlesIfSourceChanged() {
    val sourceIdentity = sourcePlaybackKey
    if (lastAddonSubtitleSourceIdentity == sourceIdentity) return
    lastAddonSubtitleSourceIdentity = sourceIdentity
    SubtitleRepository.clear()
    autoFetchedAddonSubtitlesForKey = null
}

internal fun PlayerScreenRuntime.currentPlaybackProgressPercent(
    snapshot: PlayerPlaybackSnapshot = playbackSnapshot,
): Float {
    val duration = snapshot.durationMs.takeIf { it > 0L } ?: return 0f
    return ((snapshot.positionMs.toFloat() / duration.toFloat()) * 100f)
        .coerceIn(0f, 100f)
}

internal data class TrackingScrobbleItemInputs(
    val contentType: String,
    val parentMetaId: String,
    val videoId: String?,
    val title: String,
    val seasonNumber: Int?,
    val episodeNumber: Int?,
    val episodeTitle: String?,
)

internal fun PlayerScreenRuntime.snapshotTrackingScrobbleItemInputs(): TrackingScrobbleItemInputs {
    val inputs = TrackingScrobbleItemInputs(
        contentType = contentType ?: parentMetaType,
        parentMetaId = parentMetaId,
        videoId = activeVideoId,
        title = title,
        seasonNumber = activeSeasonNumber,
        episodeNumber = activeEpisodeNumber,
        episodeTitle = activeEpisodeTitle,
    )
    if (!ServerItemRef.isServerId(parentMetaId)) return inputs
    val imdbId = (metaUiState.meta ?: playerMeta)
        ?.takeIf { it.id == parentMetaId }
        ?.imdbId
        ?.takeIf { it.startsWith("tt") }
    return if (imdbId != null) inputs.copy(parentMetaId = imdbId, videoId = null) else inputs.copy(title = "")
}

private fun TrackingScrobbleItemInputs.buildMedia(): TrackingMediaReference =
    buildTrackingMediaReference(
        contentType = contentType,
        parentMetaId = parentMetaId,
        videoId = videoId,
        title = title,
        seasonNumber = seasonNumber,
        episodeNumber = episodeNumber,
        episodeTitle = episodeTitle,
    )

internal fun PlayerScreenRuntime.currentTrackingMedia(): TrackingMediaReference =
    snapshotTrackingScrobbleItemInputs().buildMedia()

internal fun PlayerScreenRuntime.emitTrackingScrobbleStart() {
    if (isShortPlaceholderDuration(playbackSnapshot.durationMs)) return
    if (hasRequestedScrobbleStartForCurrentItem) return
    hasRequestedScrobbleStartForCurrentItem = true
    val requestGeneration = scrobbleStartRequestGeneration + 1L
    scrobbleStartRequestGeneration = requestGeneration

    scope.launch {
        if (isShortPlaceholderDuration(playbackSnapshot.durationMs)) return@launch
        val media = currentTrackingMedia()
        if (!media.hasResolvableIdentity) {
            hasRequestedScrobbleStartForCurrentItem = false
            return@launch
        }
        if (requestGeneration != scrobbleStartRequestGeneration || !hasRequestedScrobbleStartForCurrentItem) {
            return@launch
        }
        currentTrackingMedia = media
        TrackingScrobbleCoordinator.scrobble(
            profileId = profileId,
            action = TrackingScrobbleAction.START,
            event = TrackingScrobbleEvent(
                media = media,
                progressPercent = currentPlaybackProgressPercent().toDouble(),
            ),
        )
    }
}

internal fun PlayerScreenRuntime.emitTrackingScrobblePause(progressPercent: Float? = null) {
    emitTrackingScrobbleTerminal(
        action = TrackingScrobbleAction.PAUSE,
        progressPercent = progressPercent,
    )
}

internal fun PlayerScreenRuntime.emitTrackingScrobbleStop(progressPercent: Float? = null) {
    emitTrackingScrobbleTerminal(
        action = TrackingScrobbleAction.STOP,
        progressPercent = progressPercent,
    )
}

private fun PlayerScreenRuntime.emitTrackingScrobbleTerminal(
    action: TrackingScrobbleAction,
    progressPercent: Float?,
) {
    if (isShortPlaceholderDuration(playbackSnapshot.durationMs)) return
    val provided = progressPercent
    if (!hasRequestedScrobbleStartForCurrentItem && (provided ?: 0f) < 80f) return

    // Gracie: si el video no terminó, nunca se avisa >= 80 % (MDBList/Trakt lo marcarían como visto).
    val percent = capUnfinishedScrobblePercent(
        provided ?: currentPlaybackProgressPercent(),
        isEnded = playbackSnapshot.isEnded,
    )
    val mediaSnapshot = currentTrackingMedia
    val inputsSnapshot = snapshotTrackingScrobbleItemInputs()
    scope.launch(NonCancellable) {
        val media = mediaSnapshot ?: inputsSnapshot.buildMedia()
        if (!media.hasResolvableIdentity) return@launch
        TrackingScrobbleCoordinator.scrobble(
            profileId = profileId,
            action = action,
            event = TrackingScrobbleEvent(media = media, progressPercent = percent.toDouble()),
        )
    }
    currentTrackingMedia = null
    hasRequestedScrobbleStartForCurrentItem = false
    pendingSeekScrobbleRestart = false
    scrobbleStartRequestGeneration += 1L
}

internal fun PlayerScreenRuntime.emitStopScrobbleForCurrentProgress() {
    if (isShortPlaceholderDuration(playbackSnapshot.durationMs)) return
    val progressPercent = currentPlaybackProgressPercent()
    if (!shouldSendStopScrobble(hasRequestedScrobbleStartForCurrentItem, progressPercent)) {
        return
    }
    if (progressPercent < 80f || !playbackSnapshot.isEnded) {
        emitTrackingScrobbleStop(progressPercent)
        return
    }

    if (!hasSentCompletionScrobbleForCurrentItem) {
        hasSentCompletionScrobbleForCurrentItem = true
        emitTrackingScrobbleStop(progressPercent)
    }
}

internal const val UnfinishedScrobbleMaxPercent = 79f

internal fun capUnfinishedScrobblePercent(
    progressPercent: Float,
    isEnded: Boolean,
): Float = if (isEnded) progressPercent else progressPercent.coerceAtMost(UnfinishedScrobbleMaxPercent)

internal fun shouldSendStopScrobble(
    hasActiveScrobble: Boolean,
    progressPercent: Float,
): Boolean = hasActiveScrobble || progressPercent >= 80f

internal fun shouldUpdateTrackingScrobbleAfterSeek(
    hasActiveScrobble: Boolean,
    progressPercent: Float,
): Boolean = hasActiveScrobble && progressPercent >= 1f && progressPercent < 80f

internal fun PlayerScreenRuntime.emitTrackingSeekScrobbleStart() {
    if (isShortPlaceholderDuration(playbackSnapshot.durationMs)) return
    val mediaSnapshot = currentTrackingMedia
    val inputsSnapshot = snapshotTrackingScrobbleItemInputs()
    scope.launch {
        if (isShortPlaceholderDuration(playbackSnapshot.durationMs)) return@launch
        val media = mediaSnapshot ?: inputsSnapshot.buildMedia()
        if (!media.hasResolvableIdentity) return@launch
        TrackingScrobbleCoordinator.scrobbleSeek(
            profileId = profileId,
            action = TrackingScrobbleAction.START,
            event = TrackingScrobbleEvent(
                media = media,
                progressPercent = currentPlaybackProgressPercent().toDouble(),
            ),
        )
    }
}

internal fun PlayerScreenRuntime.tryShowParentalGuide() {
    if (!playerSettingsUiState.showParentalGuide) return
    if (!parentalGuideHasShown && parentalWarnings.isNotEmpty() && !playbackStartedForParentalGuide) {
        playbackStartedForParentalGuide = true
        showParentalGuide = true
        parentalGuideHasShown = true
    }
}

internal suspend fun PlayerScreenRuntime.resolveParentalGuideImdbId(): String? {
    val candidates = listOf(parentMetaId, activeVideoId)
    candidates.firstNotNullOfOrNull(::extractParentalGuideImdbId)?.let { return it }
    // Fallback: use imdb_id from addon meta response
    val metaImdbId = (metaUiState.meta ?: playerMeta)
        ?.takeIf { it.id == parentMetaId }
        ?.imdbId
        ?.takeIf { it.startsWith("tt") }
    if (metaImdbId != null) return metaImdbId
    val tmdbId = candidates.firstNotNullOfOrNull(::extractParentalGuideTmdbId) ?: return null
    return TmdbService.tmdbToImdb(
        tmdbId = tmdbId,
        mediaType = contentType ?: parentMetaType,
    )
}

internal fun PlayerScreenRuntime.flushWatchProgress(
    scrobbleAction: TrackingScrobbleAction = TrackingScrobbleAction.STOP,
) {
    when (scrobbleAction) {
        TrackingScrobbleAction.PAUSE -> emitTrackingScrobblePause()
        TrackingScrobbleAction.STOP -> emitStopScrobbleForCurrentProgress()
        TrackingScrobbleAction.START -> Unit
    }
    WatchProgressRepository.flushPlaybackProgress(
        session = playbackSession,
        snapshot = playbackSnapshot,
    )
}

internal fun PlayerScreenRuntime.scheduleProgressSyncAfterSeek() {
    val shouldRestartScrobbleAfterSeek = shouldPlay || playbackSnapshot.isPlaying
    seekProgressSyncJob?.cancel()
    seekProgressSyncJob = scope.launch {
        delay(PlayerSeekProgressSyncDebounceMs)
        if (isShortPlaceholderDuration(playbackSnapshot.durationMs)) return@launch
        WatchProgressRepository.upsertPlaybackProgress(
            session = playbackSession,
            snapshot = playbackSnapshot,
        )

        val progressPercent = currentPlaybackProgressPercent()
        if (
            !shouldUpdateTrackingScrobbleAfterSeek(
                hasActiveScrobble = hasRequestedScrobbleStartForCurrentItem,
                progressPercent = progressPercent,
            )
        ) {
            return@launch
        }

        val media = currentTrackingMedia ?: currentTrackingMedia()
        if (!media.hasResolvableIdentity) return@launch
        val stopEvent = TrackingScrobbleEvent(
            media = media,
            progressPercent = progressPercent.toDouble(),
        )
        scope.launch {
            if (isShortPlaceholderDuration(playbackSnapshot.durationMs)) return@launch
            TrackingScrobbleCoordinator.scrobbleSeek(
                profileId = profileId,
                action = TrackingScrobbleAction.STOP,
                event = stopEvent,
            )
            if (!shouldRestartScrobbleAfterSeek || !shouldPlay || playbackSnapshot.isEnded ||
                isShortPlaceholderDuration(playbackSnapshot.durationMs)
            ) return@launch
            if (playbackSnapshot.isPlaying) {
                pendingSeekScrobbleRestart = false
                TrackingScrobbleCoordinator.scrobbleSeek(
                    profileId = profileId,
                    action = TrackingScrobbleAction.START,
                    event = stopEvent.copy(
                        progressPercent = currentPlaybackProgressPercent().toDouble(),
                    ),
                )
            } else {
                pendingSeekScrobbleRestart = true
            }
        }
    }
}

internal fun PlayerScreenRuntime.persistPlaybackProgressTick() {
    val now = WatchProgressClock.nowEpochMs()
    if (now - lastProgressPersistEpochMs < PlaybackProgressPersistIntervalMs) return
    lastProgressPersistEpochMs = now
    WatchProgressRepository.upsertPlaybackProgress(
        session = playbackSession,
        snapshot = playbackSnapshot,
        syncRemote = false,
    )
}

internal val AndroidPlaybackEngine.switchTarget: AndroidPlaybackEngine
    get() = if (this == AndroidPlaybackEngine.Libmpv) AndroidPlaybackEngine.ExoPlayer else AndroidPlaybackEngine.Libmpv

internal fun PlayerScreenRuntime.switchPlaybackEngine() {
    val target = playerController?.playbackEngine?.switchTarget ?: return
    flushWatchProgress()
    if (initialSeekApplied) {
        activeInitialPositionMs = playbackSnapshot.positionMs.coerceAtLeast(0L)
        activeInitialProgressFraction = null
    }
    // Capture the current track selection so it can be restored on the new engine.
    rememberCurrentTrackPreferenceForEngineSwitch(target)
    playbackEngineOverride = target
    // A manual switch is an explicit user decision: never let the automatic engine
    // failover drag the user back to the engine they just switched away from.
    engineFailoverDisarmed = true
    showGestureFeedback(
        GestureFeedbackState(
            messageRes = Res.string.player_engine_switching_manual_message,
            messageArgs = listOf(target.label),
        ),
    )
}

/**
 * Switches to the opposite playback engine after a playback error, when the
 * "auto-switch engine on playback error" setting is enabled. Applies whichever engine is
 * selected; fires at most once per source, after the engine's own retries, and never after a
 * manual engine switch.
 *
 * @return true when the failover was started and the caller should swallow the error.
 */
internal fun PlayerScreenRuntime.maybeFailoverPlaybackEngine(
    resolvedAutoEngine: AndroidPlaybackEngine?,
): Boolean {
    if (!playerSettingsUiState.autoSwitchPlaybackEngineOnError) return false
    if (engineFailoverDisarmed) return false
    val sourceIdentity = activePlaybackIdentity
    if (engineFailoverSourceIdentity == sourceIdentity) return false

    val current = playerController?.playbackEngine
        ?: playbackEngineOverride
        ?: resolvedAutoEngine
        ?: playerSettingsUiState.androidPlaybackEngine
    val target = if (current == AndroidPlaybackEngine.Libmpv) {
        AndroidPlaybackEngine.ExoPlayer
    } else {
        AndroidPlaybackEngine.Libmpv
    }

    engineFailoverTriggered = true
    engineFailoverSourceIdentity = sourceIdentity
    flushWatchProgress()
    if (initialSeekApplied) {
        activeInitialPositionMs = playbackSnapshot.positionMs.coerceAtLeast(0L)
        activeInitialProgressFraction = null
    }
    // Capture the current track selection so it can be restored on the new engine.
    rememberCurrentTrackPreferenceForEngineSwitch(target)
    playbackEngineOverride = target
    showGestureFeedback(
        GestureFeedbackState(
            messageRes = Res.string.player_engine_switching_automatic_message,
            messageArgs = listOf(target.label),
        ),
    )
    return true
}

internal fun PlayerScreenRuntime.openStreamInfo() {
    refreshTracks()
    val controller = playerController
    scope.launch {
        streamMediaInfo = controller?.getMediaInfo() ?: PlayerMediaInfo()
        showStreamInfo = true
    }
}
