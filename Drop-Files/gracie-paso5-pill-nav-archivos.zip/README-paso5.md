# Paso 5 — Menú de arriba (píldora de navegación)

Sin TV en vivo (como pediste).

## Qué incluye
1. **Persistencia Android** (`PillNavPreferencesAndroid.kt`) + llamada en `MainActivity`.
   Sin esto, el interruptor de Ajustes no se guarda y `isAvailable` queda en false (la sección ni aparece).
2. **`PillNavigationBar.kt` completo** — el composable real de la píldora superior (glass, indicador líquido, tabs de texto, ajustes, avatar).
   En tu árbol solo estaban tokens/helpers; faltaba el `@Composable PillNavigationBar` y `rememberPillNavState` / `pillNavContent`.
3. **Cableado en `MainTabsDestination.kt`** — cuando el interruptor está ON, usa la píldora de arriba y oculta la barra flotante inferior/tablet.
4. **Textos en español** del interruptor en Ajustes.

## Qué NO incluye
- Pestaña / botón de TV en vivo
- Cambios en `AppScreenTab`, Live TV, iOS, desktop, workflows

## Cómo aplicar
Copia estos archivos encima de tu proyecto (mismas rutas relativas a la raíz del repo).

## Cómo probar
1. Compila e instala.
2. Ajustes → sección Navigation → activa "Pill menu" / "Menú píldora".
3. Debería aparecer la píldora arriba (Home / Search / Library + engranaje + avatar) y desaparecer la barra inferior.
4. Cierra la app y vuelve a abrir: el interruptor debe seguir activo.
