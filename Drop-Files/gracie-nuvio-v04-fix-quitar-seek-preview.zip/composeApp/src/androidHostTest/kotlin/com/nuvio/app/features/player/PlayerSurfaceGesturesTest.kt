package com.nuvio.app.features.player

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.test.click
import androidx.compose.ui.test.doubleClick
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.longClick
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performTouchInput
import androidx.compose.ui.test.swipe
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import org.junit.Rule
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class PlayerSurfaceGesturesTest {
    @get:Rule
    val compose = createComposeRule()

    private val playbackReady = mutableStateOf(false)
    private var backGestureEdgePx = 0f
    private val controlsLocked = mutableStateOf(false)
    private var taps = 0
    private var doubleTaps = 0
    private var speedBoosts = 0
    private var seekCommits = 0
    private var sideAdjustments = 0
    private val gestureController = object : PlayerGestureController {
        override fun currentBrightness() = 0.5f
        override fun currentVolume() = PlayerAudioLevel(0.5f, false)
        override fun setBrightness(level: Float): Float {
            sideAdjustments++
            return level
        }
        override fun setVolume(level: Float): PlayerAudioLevel {
            sideAdjustments++
            return PlayerAudioLevel(level, false)
        }
    }

    private fun setContent() {
        compose.setContent {
            val locked = rememberUpdatedState(controlsLocked.value)
            val noop = rememberUpdatedState<() -> Unit>({})
            Box(
                Modifier.size(320.dp, 180.dp)
                    .testTag("surface")
                    .playerSurfaceTapGestures(
                        layoutSize = IntSize(320, 180),
                        playbackGesturesEnabled = playbackReady.value,
                        playerControlsLockedState = locked,
                        onSurfaceTap = rememberUpdatedState { _: Offset -> taps++ },
                        onSurfaceDoubleTap = rememberUpdatedState { _: Offset -> doubleTaps++ },
                        activateHoldToSpeedState = rememberUpdatedState { speedBoosts++ },
                        deactivateHoldToSpeedState = noop,
                        revealLockedOverlayState = noop,
                    )
                    .playerSurfaceDragGestures(
                        gestureController = gestureController,
                        layoutSize = IntSize(320, 180),
                        playbackGesturesEnabled = playbackReady.value,
                        sideGestureSystemEdgeExclusionPx = 0f,
                        horizontalSeekSystemEdgeExclusionPx = backGestureEdgePx,
                        playerControlsLockedState = locked,
                        touchGesturesEnabledState = rememberUpdatedState(true),
                        isHoldToSpeedGestureActiveState = rememberUpdatedState(false),
                        currentPositionMsState = rememberUpdatedState(30_000L),
                        currentDurationMsState = rememberUpdatedState(120_000L),
                        deactivateHoldToSpeedState = noop,
                        showBrightnessFeedbackState = rememberUpdatedState { _: Float -> },
                        showVolumeFeedbackState = rememberUpdatedState { _: PlayerAudioLevel -> },
                        clearLiveGestureFeedbackState = noop,
                        revealLockedOverlayState = noop,
                        commitHorizontalSeekState = rememberUpdatedState { _: Long -> seekCommits++ },
                    ),
            )
        }
    }

    private fun performPlaybackGestures() {
        val surface = compose.onNodeWithTag("surface")
        surface.performTouchInput { doubleClick(Offset(width * 0.85f, centerY)) }
        surface.performTouchInput { swipe(center, Offset(width * 0.85f, centerY)) }
        surface.performTouchInput { longClick(center) }
        surface.performTouchInput { swipe(Offset(width * 0.1f, centerY), Offset(width * 0.1f, height * 0.1f)) }
        surface.performTouchInput { swipe(Offset(width * 0.9f, centerY), Offset(width * 0.9f, height * 0.1f)) }
    }

    @Test
    fun loadingIgnoresPlaybackGesturesButAllowsTappingControls() {
        setContent()
        compose.onNodeWithTag("surface").performTouchInput { click(center) }
        performPlaybackGestures()
        compose.runOnIdle {
            assertTrue(taps > 0)
            assertEquals(0, doubleTaps)
            assertEquals(0, speedBoosts)
            assertEquals(0, seekCommits)
            assertEquals(0, sideAdjustments)
        }
    }

    @Test
    fun completingInitialLoadEnablesPlaybackGestures() {
        setContent()
        compose.runOnIdle { playbackReady.value = true }
        performPlaybackGestures()
        compose.runOnIdle {
            assertEquals(1, doubleTaps)
            assertEquals(1, speedBoosts)
            assertEquals(1, seekCommits)
            assertTrue(sideAdjustments > 0)
        }
    }

    @Test
    fun lockingControlsPreservesTapsWithSmallFingerMovement() {
        playbackReady.value = true
        setContent()
        compose.runOnIdle { controlsLocked.value = true }
        compose.onNodeWithTag("surface").performTouchInput {
            down(center)
            moveTo(center + Offset(1f, 1f))
            up()
        }
        compose.mainClock.advanceTimeBy(400)
        compose.runOnIdle { assertEquals(1, taps) }
    }

    @Test
    fun lockedControlsIgnoreSeekAndSideGestures() {
        playbackReady.value = true
        controlsLocked.value = true
        setContent()
        val surface = compose.onNodeWithTag("surface")
        surface.performTouchInput { swipe(center, Offset(width * 0.85f, centerY)) }
        surface.performTouchInput { swipe(Offset(width * 0.1f, centerY), Offset(width * 0.1f, height * 0.1f)) }
        surface.performTouchInput { swipe(Offset(width * 0.9f, centerY), Offset(width * 0.9f, height * 0.1f)) }
        compose.runOnIdle {
            assertEquals(0, seekCommits)
            assertEquals(0, sideAdjustments)
        }
    }

    @Test
    fun loadingAnotherSourceCancelsAnInProgressSeek() {
        playbackReady.value = true
        setContent()
        val surface = compose.onNodeWithTag("surface")
        surface.performTouchInput {
            down(center)
            moveTo(Offset(width * 0.85f, centerY))
        }
        compose.runOnIdle {
            playbackReady.value = false
        }
        surface.performTouchInput { up() }
        compose.runOnIdle { assertEquals(0, seekCommits) }
    }

    @Test
    fun gestureNavigationEdgesLeaveHorizontalSwipesToTheSystemBackGesture() {
        playbackReady.value = true
        backGestureEdgePx = 40f
        setContent()
        val surface = compose.onNodeWithTag("surface")
        surface.performTouchInput { swipe(Offset(width - 2f, centerY), Offset(width * 0.5f, centerY)) }
        surface.performTouchInput { swipe(Offset(2f, centerY), Offset(width * 0.5f, centerY)) }
        compose.runOnIdle {
            assertEquals(0, seekCommits)
        }
        surface.performTouchInput { swipe(center, Offset(width * 0.85f, centerY)) }
        compose.runOnIdle { assertEquals(1, seekCommits) }
    }

    @Test
    fun slowEdgeSwipeDoesNotActivateHoldToSpeed() {
        playbackReady.value = true
        backGestureEdgePx = 40f
        setContent()
        compose.onNodeWithTag("surface").performTouchInput {
            down(Offset(width - 2f, centerY))
            repeat(10) { step ->
                moveTo(Offset(width - 2f - (step + 1) * 4f, centerY))
                advanceEventTime(100)
            }
            up()
        }
        compose.runOnIdle {
            assertEquals(0, speedBoosts)
            assertEquals(0, seekCommits)
        }
    }

    @Test
    fun stillFingerHoldStillActivatesHoldToSpeed() {
        playbackReady.value = true
        backGestureEdgePx = 40f
        setContent()
        compose.onNodeWithTag("surface").performTouchInput { longClick(Offset(width - 2f, centerY)) }
        compose.runOnIdle { assertEquals(1, speedBoosts) }
    }
}
