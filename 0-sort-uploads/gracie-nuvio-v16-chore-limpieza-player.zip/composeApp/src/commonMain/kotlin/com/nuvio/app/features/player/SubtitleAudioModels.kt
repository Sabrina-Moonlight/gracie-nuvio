package com.nuvio.app.features.player

import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.nuvio.app.isIos
import nuvio.composeapp.generated.resources.Res
import nuvio.composeapp.generated.resources.compose_player_track_number
import org.jetbrains.compose.resources.stringResource
import kotlin.math.pow
import kotlin.math.roundToInt

data class AudioTrack(
    val index: Int,
    val id: String,
    val label: String,
    val language: String? = null,
    val isSelected: Boolean = false,
)

data class SubtitleTrack(
    val index: Int,
    val id: String,
    val label: String,
    val language: String? = null,
    val isSelected: Boolean = false,
    val isForced: Boolean = false,
    val formatBadge: SubtitleFormatBadge? = null,
)

enum class SubtitleFormatBadge(val label: String) {
    ASS("ASS"),
    PGS("PGS"),
    VOBSUB("VobSub"),
    DVB("DVB"),
}

internal fun subtitleFormatBadgeForCodec(codec: String?): SubtitleFormatBadge? =
    when (codec?.trim()?.lowercase()) {
        "ass", "ssa" -> SubtitleFormatBadge.ASS
        "hdmv_pgs_subtitle", "pgssub" -> SubtitleFormatBadge.PGS
        "dvd_subtitle", "dvdsub" -> SubtitleFormatBadge.VOBSUB
        "dvb_subtitle", "dvbsub" -> SubtitleFormatBadge.DVB
        else -> null
    }

data class AddonSubtitle(
    val id: String,
    val url: String,
    val language: String,
    val display: String,
    val addonName: String? = null,
    val isSelected: Boolean = false,
    val label: String? = null,
    val title: String? = null,
)

const val SUBTITLE_DELAY_MIN_MS = -60_000
const val SUBTITLE_DELAY_MAX_MS = 60_000
const val SUBTITLE_DELAY_STEP_MS = 100
const val SUBTITLE_AUTO_SYNC_REACTION_COMPENSATION_MS = 300L
const val AUDIO_DELAY_MIN_MS = -60_000
const val AUDIO_DELAY_MAX_MS = 60_000
const val AUDIO_DELAY_STEP_MS = 25
const val AUDIO_AMPLIFICATION_MIN_DB = 0
const val AUDIO_AMPLIFICATION_MAX_DB = 10
/** Center channel level in the FFmpeg downmix, relative to the stream's own (or -3 dB). */
const val CENTER_MIX_LEVEL_MIN_DB = -10
const val CENTER_MIX_LEVEL_MAX_DB = 30

/** Speaker layouts the FFmpeg downmix can produce. */
enum class AudioOutputChannels(
    val settingValue: String,
    val channelCount: Int,
    val ffmpegLayoutName: String,
) {
    CHANNELS_2_0("2.0", 2, "stereo"),
    CHANNELS_2_1("2.1", 3, "2.1"),
    CHANNELS_3_0("3.0", 3, "3.0"),
    CHANNELS_3_1("3.1", 4, "3.1"),
    CHANNELS_4_0("4.0", 4, "4.0"),
    CHANNELS_4_1("4.1", 5, "4.1"),
    CHANNELS_5_0("5.0", 5, "5.0"),
    CHANNELS_5_1("5.1", 6, "5.1"),
    CHANNELS_7_0("7.0", 7, "7.0"),
    CHANNELS_7_1("7.1", 8, "7.1");

    companion object {
        /** Phones and tablets play stereo. */
        val default = CHANNELS_2_0

        fun fromSettingValue(value: String?): AudioOutputChannels =
            entries.firstOrNull { it.settingValue == value } ?: default
    }
}

/** The downmix setting only works through the app's FFmpeg audio decoder ("Prefer app decoders"). */
val PlayerSettingsUiState.effectiveDownmixEnabled: Boolean
    get() = downmixEnabled && decoderPriority == 2

/** Linear gain factor for an amplification of [db] decibels. */
internal fun audioAmplificationGain(db: Int): Double =
    10.0.pow(db.coerceIn(AUDIO_AMPLIFICATION_MIN_DB, AUDIO_AMPLIFICATION_MAX_DB) / 20.0)

internal const val SUBTITLE_OUTLINE_WIDTH_DEFAULT = 2
internal val subtitleOutlineWidthRange: IntRange = 1..5

internal val subtitleFontSizeRangeSp: IntRange
    get() = if (isIos) 6..40 else 12..60

data class SubtitleStyleState(
    val textColor: Color = Color.White,
    val backgroundColor: Color = Color.Transparent,
    val outlineColor: Color = Color.Black,
    val outlineEnabled: Boolean = true,
    val outlineWidth: Int = SUBTITLE_OUTLINE_WIDTH_DEFAULT,
    val bold: Boolean = false,
    val fontSizeSp: Int = 18,
    val bottomOffset: Int = 20,
    val stripSdh: Boolean = false,
    val useForcedSubtitles: Boolean = true,
    val showOnlyPreferredLanguages: Boolean = false,
    val appearance: SubtitleAppearance = SubtitleAppearance(),
) {
    companion object {
        val DEFAULT = SubtitleStyleState()
    }
}

data class SubtitleSyncCue(
    val startTimeMs: Long,
    val endTimeMs: Long = startTimeMs + 5_000L,
    val text: String,
)

data class SubtitleAutoSyncUiState(
    val capturedPositionMs: Long? = null,
    val cues: List<SubtitleSyncCue> = emptyList(),
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
)

val SubtitleColorSwatches = listOf(
    Color.White,
    Color(0xFFFFD700),
    Color(0xFF00E5FF),
    Color(0xFFFF5C5C),
    Color(0xFF00FF88),
    Color(0xFF9B59B6),
    Color(0xFFF97316),
    Color(0xFF22C55E),
    Color(0xFF3B82F6),
    Color.Black,
)

fun Color.toStorageHexString(): String {
    fun component(value: Float): String =
        (value * 255f).roundToInt().coerceIn(0, 255).toString(16).padStart(2, '0').uppercase()

    return buildString {
        append('#')
        append(component(alpha))
        append(component(red))
        append(component(green))
        append(component(blue))
    }
}

fun subtitleColorFromStorage(value: String?): Color? {
    val normalized = value
        ?.trim()
        ?.removePrefix("#")
        ?.takeIf { it.length == 6 || it.length == 8 }
        ?: return null

    val argb = if (normalized.length == 6) {
        "FF$normalized"
    } else {
        normalized
    }

    val parsed = argb.toLongOrNull(16) ?: return null
    return Color(
        red = ((parsed shr 16) and 0xFF).toFloat() / 255f,
        green = ((parsed shr 8) and 0xFF).toFloat() / 255f,
        blue = (parsed and 0xFF).toFloat() / 255f,
        alpha = ((parsed shr 24) and 0xFF).toFloat() / 255f,
    )
}

@Composable
fun localizedTrackDisplayName(label: String?, language: String?, index: Int): String {
    if (!label.isNullOrBlank()) return label
    if (!language.isNullOrBlank()) return languageLabelForCode(language)
    return stringResource(Res.string.compose_player_track_number, index + 1)
}
