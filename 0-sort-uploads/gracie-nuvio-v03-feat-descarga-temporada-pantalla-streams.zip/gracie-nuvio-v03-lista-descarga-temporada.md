# Lista — Gracie Nuvio (descargar temporadas)
APP = `nuvio` (ZIP: `gracie-nuvio-vNN-TIPO-descripcion.zip`). Reglas: `claude.md`. Notas de actualización de Nuvio: `gracie-nuvio/NOTAS-ACTUALIZACION.md`. Versión base de Nuvio: 1.1.0-beta.2.

## Hecho
- v01/v02: opción **Descargar temporada** al mantener pulsada una temporada o un capítulo. Mostraba una hoja propia con resultados por addon (NO era lo que ella quería; se retira en v03).
- v03 `gracie-nuvio-v03-feat-descarga-temporada-pantalla-streams.zip`: **Descargar temporada** ahora abre la pantalla de streams normal (la de elegir torrent) del primer capítulo en "modo descarga". Al tocar un resultado se descarga (no se reproduce) y se pasa solo a la pantalla del capítulo siguiente, hasta el último. Arriba a la derecha hay un botón "n/total · Saltar". Atrás cancela el resto. Si la descarga falla (sin enlace / formato no soportado) se queda en el mismo capítulo.

## Pendiente (en este orden, una parte por entrega)
1. Probar v03 y contar qué falla o qué falta (compilación, que salten bien los capítulos, que no empiece a reproducir solo).
2. Idea: "usar el mismo tipo de resultado en todos los capítulos" (por calidad/tamaño o palabra, p. ej. 1080p) para no elegir 24 veces.
3. Idea: incluir también plugins y servidores (en modo descarga ya salen los de la pantalla normal).

## Para retomar
- Archivos de Nuvio tocados (ojo al actualizar Nuvio): `StreamDestination.kt` (modo descarga: `downloadMode`, `downloadSelectedStream`, `advanceDownloadQueue`, botón Saltar), `DetailsDestinations.kt` (crea el `StreamLaunch` del primer capítulo con la cola), `features/details/MetaDetailsScreen.kt` (parámetro `onDownloadSeason`; ya no hay hoja propia), `features/streams/StreamLaunchStore.kt` (`DownloadQueueEpisode`, `downloadQueue/downloadPosition/downloadTotal` en `StreamLaunch`), `features/details/components/EpisodeWatchedActionSheet.kt` (parámetro opcional `onDownloadSeason`).
- Archivos solo de Gracie: `composeResources/values/season_download_strings.xml` y `values-es/` (acción, "Saltar", "Temporada terminada"). Borrados en v03: `SeasonDownloadSheet.kt`, `EpisodeStreamsLoader.kt`.
- Cómo evita reproducir: la cola usa `manualSelection = true` (sin autoplay ni reutilizar último enlace) y `StreamDestination` desvía el toque a descargar.
- Suposiciones: solo capítulos ya estrenados; el menú de mantener pulsado dentro de la pantalla sigue igual (su "Descargar" no avanza de capítulo).
- Nunca se ha compilado. Si falla, pedir la línea roja.
